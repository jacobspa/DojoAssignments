def questions(request):
    is_valid = True
    if request.form['html_1'] < 18:
        messages.error(request, 'Must be 18 or older to Register for Validating.com')
        is_valid = False
    question_1 = request.form['html_1']
    question_2 = request.form['html_2']
    question_3 = request.form['html_3']
    question_4 = request.form['html_4']
    question_5 = request.form['html_5']
    question_6 = request.form['html_6']
    question_7 = request.form['html_7']
    question_8 = request.form['html_8']
    question_9 = request.form['html_9']
    question_10 = request.form['html_10']
